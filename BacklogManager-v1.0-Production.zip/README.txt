﻿# Backlog Manager - BNP Paribas

Application de gestion de backlog et de suivi de projet dÃ©veloppÃ©e pour BNP Paribas. Permet la gestion des tÃ¢ches, le suivi en Kanban, la planification des sprints, le compte-rendu d'activitÃ© (CRA) et l'analyse des KPI.

## ðŸ” Authentification
- Connexion avec **code d'authentification BNP** (format: JXXXXX)
- L'application identifie automatiquement l'utilisateur et ses permissions
- Pas de mot de passe requis (simulation d'authentification Windows)

## ðŸ‘¥ RÃ´les et Permissions

### ðŸ‘¨â€ðŸ’¼ Administrateur
- âœ… AccÃ¨s complet Ã  toutes les fonctionnalitÃ©s
- âœ… Gestion des utilisateurs et de l'Ã©quipe
- âœ… Gestion des projets et rÃ©fÃ©rentiels
- âœ… Consultation des logs d'audit
- âœ… AccÃ¨s aux paramÃ¨tres systÃ¨me (sauvegarde, export/import)
- âœ… CrÃ©ation de tÃ¢ches normales et spÃ©ciales (congÃ©s/support)

### ðŸ“Š Chef de Projet (CP)
- âœ… CrÃ©ation et gestion de projets
- âœ… Priorisation des tÃ¢ches
- âœ… Assignation des dÃ©veloppeurs aux tÃ¢ches
- âœ… Consultation des KPI et statistiques
- âœ… Suivi du planning et des sprints
- âœ… CrÃ©ation de tÃ¢ches normales et spÃ©ciales
- âŒ Pas d'accÃ¨s aux paramÃ¨tres systÃ¨me

### ðŸ§‘â€ðŸ’» Business Analyst (BA)
- âœ… CrÃ©ation de demandes et user stories
- âœ… CrÃ©ation de tÃ¢ches normales
- âœ… Consultation du backlog et des KPI
- âœ… Suivi des tÃ¢ches
- âœ… CrÃ©ation de congÃ©s/support
- âŒ Pas de priorisation
- âŒ Pas de gestion d'Ã©quipe

### ðŸ’» DÃ©veloppeur
- âœ… Consultation du backlog
- âœ… Mise Ã  jour du statut des tÃ¢ches assignÃ©es
- âœ… Saisie du CRA (temps passÃ©)
- âœ… CrÃ©ation de congÃ©s et support uniquement
- âœ… Vue Kanban pour le suivi quotidien
- âŒ Pas de crÃ©ation de tÃ¢ches normales
- âŒ Pas de priorisation
- âŒ Pas d'accÃ¨s administration

## âœ¨ FonctionnalitÃ©s principales

### ðŸ  Dashboard
- Vue d'ensemble avec indicateurs clÃ©s
- **ActivitÃ©s rÃ©centes** : affichage dynamique des derniÃ¨res actions (crÃ©ation/modification de tÃ¢ches, congÃ©s, support, temps saisi)
- ActivitÃ©s cliquables : navigation vers la tÃ¢che concernÃ©e (Backlog ou Archives)
- TÃ¢ches urgentes avec Ã©chÃ©ances
- Notifications importantes
- Actions rapides (nouvelle tÃ¢che, Kanban, Timeline)
- Guide utilisateur intÃ©grÃ©

### ðŸ“‹ Backlog
- Liste complÃ¨te des tÃ¢ches et demandes
- Filtres avancÃ©s (type, prioritÃ©, statut, dÃ©veloppeur, projet)
- Recherche par titre
- 3 vues : TÃ¢ches, Projets, Archives
- **Permissions adaptÃ©es** :
  - DÃ©veloppeurs : voient uniquement "âž• CongÃ©s/Support"
  - Admin/BA/CP : voient "âž• Nouvelle TÃ¢che" + "âž• CongÃ©s/Support"
- Ã‰dition des dÃ©tails d'une tÃ¢che (selon permissions)

### ðŸ“Š Kanban Board
- Vue en colonnes : Ã€ Faire â†’ En Attente â†’ Ã€ Prioriser â†’ En Cours â†’ Test â†’ TerminÃ©
- Drag & drop pour changer le statut
- Alertes visuelles selon les dÃ©lais (URGENT, ATTENTION, OK)
- Filtres par dÃ©veloppeur et projet
- Cartes compactes : titre, prioritÃ©, type, dÃ©veloppeur, temps restant, progression

### ðŸ“ Projets
- CrÃ©ation et gestion des projets
- Association des tÃ¢ches aux projets
- Activation/dÃ©sactivation des projets
- Suivi de l'avancement par projet

### â±ï¸ Timeline / Planning
- Vue Gantt du planning des tÃ¢ches
- Visualisation des sprints
- Suivi des Ã©chÃ©ances
- Planning des congÃ©s et disponibilitÃ©s

### ðŸ“ CRA (Compte-Rendu d'ActivitÃ©)
- **Vue Calendrier** : saisie mensuelle du temps passÃ©
- **Vue Historique** : consultation des CRA passÃ©s avec filtres
- Saisie en jours (1j = 8h)
- Types d'activitÃ© : Run, Dev, Autre, CongÃ©s, Non TravaillÃ©, Support
- Calcul automatique des jours fÃ©riÃ©s franÃ§ais
- Validation et corrections des saisies
- Export des donnÃ©es

### ðŸ“ˆ Statistiques & KPI
- VÃ©locitÃ© de l'Ã©quipe
- Taux de complÃ©tion
- RÃ©partition par prioritÃ©
- Analyse des dÃ©lais
- Graphiques et mÃ©triques de performance
- Temps passÃ© vs estimÃ©

### ðŸ”” Notifications
- Alertes sur les tÃ¢ches urgentes
- Rappels de deadlines
- Notifications des changements de statut
- Centre de notifications centralisÃ©

### ðŸ§‘â€ðŸ’¼ Gestion d'Ã©quipe (Admin uniquement)
- Liste des membres de l'Ã©quipe
- Attribution des rÃ´les
- Gestion des capacitÃ©s (jours disponibles par sprint)
- Activation/dÃ©sactivation des utilisateurs
- Modification des informations utilisateur

### ðŸ” Audit (Admin uniquement)
- TraÃ§abilitÃ© complÃ¨te des actions
- Logs avec : date, utilisateur, action, type d'entitÃ©, dÃ©tails
- Filtres par date, utilisateur et type d'action
- Export des logs
- IntÃ©gration dans le Dashboard (activitÃ©s rÃ©centes)

### âš™ï¸ ParamÃ¨tres (Admin uniquement)
- **Sauvegarde automatique** : 
  - Activation/dÃ©sactivation par checkbox
  - Intervalle configurable (5-120+ minutes)
  - Affichage de la prochaine sauvegarde
  - Nettoyage automatique (garde les 10 derniÃ¨res)
  - Fichiers : `backup_auto_YYYYMMDD_HHMMSS.db`
- **Sauvegarde manuelle** :
  - Bouton de crÃ©ation manuelle
  - Fichiers : `backup_manual_YYYYMMDD_HHMMSS.db`
  - Affichage de la derniÃ¨re sauvegarde
- **Export de donnÃ©es** :
  - Export SQLite (.db) : copie complÃ¨te de la base
  - Export JSON : donnÃ©es structurÃ©es (BacklogItems, Projets, Utilisateurs)
  - Export Complet : ZIP contenant SQLite + JSON + README
  - Export CSV : backlog uniquement (compatibilitÃ©)
- **Import de donnÃ©es** :
  - Import SQLite : remplacement de la base (avec backup automatique)
  - Import JSON : prÃ©parÃ© pour import futur
- Affichage du chemin de la base de donnÃ©es
- Gestion des thÃ¨mes (prÃ©parÃ© pour futur)

## ðŸ“¦ Types de tÃ¢ches

### TÃ¢ches normales (Admin/BA/CP uniquement)
- **User Story** : FonctionnalitÃ© mÃ©tier
- **Bug** : Correction d'anomalie
- **AmÃ©lioration** : Optimisation existante
- **Technique** : Dette technique, refactoring
- **Run** : TÃ¢che de production/maintenance

### TÃ¢ches spÃ©ciales (Tous les utilisateurs)
- **CongÃ©s** : Vacances, RTT, congÃ©s payÃ©s
- **Non TravaillÃ©** : Absences diverses
- **Support** : Aide Ã  un collÃ¨gue dÃ©veloppeur

## ðŸŽ¯ Niveaux de prioritÃ©
- **ðŸ”´ Urgente** : Traitement immÃ©diat requis
- **ðŸŸ  Haute** : Important, Ã  traiter rapidement
- **ðŸŸ¡ Moyenne** : PrioritÃ© standard
- **ðŸŸ¢ Basse** : Peut attendre

## ðŸ”„ Workflow des tÃ¢ches
1. **Ã€ Faire** : TÃ¢che crÃ©Ã©e, prÃªte Ã  Ãªtre dÃ©marrÃ©e
2. **En Attente** : BloquÃ©e, en attente de dÃ©pendances
3. **Ã€ Prioriser** : NÃ©cessite une dÃ©cision de prioritÃ©
4. **En Cours** : DÃ©veloppement en cours
5. **Test** : En phase de validation/tests
6. **TerminÃ©** : TÃ¢che complÃ©tÃ©e et validÃ©e

## ðŸ’¾ Stockage des donnÃ©es

**Base de donnÃ©es** : SQLite (`backlog.db`)
- Localisation : `bin/Debug/data/backlog.db` ou `bin/Release/data/backlog.db`
- CrÃ©ation automatique au premier lancement
- **Sauvegardes automatiques** (si activÃ©es dans ParamÃ¨tres)
- **Sauvegardes manuelles** disponibles
- Dossier des backups : `Backups/` (mÃªme rÃ©pertoire que l'exÃ©cutable)

**Tables principales** :
- BacklogItems (tÃ¢ches)
- Projets
- Utilisateurs
- Roles
- CRA (compte-rendu d'activitÃ©)
- Sprints
- AuditLogs (traÃ§abilitÃ©)
- Demandes

## ðŸ› ï¸ Technologies

- **Framework** : WPF (.NET Framework 4.8)
- **Base de donnÃ©es** : SQLite (System.Data.SQLite)
- **Architecture** : MVVM (Model-View-ViewModel)
- **Langage** : C# 8.0
- **SÃ©rialisation** : System.Text.Json
- **Compression** : System.IO.Compression (export ZIP)

## ðŸŽ¨ Branding
- **Couleur principale** : BNP Green (#00915A)
- Interface claire avec accents verts
- Design moderne et Ã©purÃ©
- Logo BNP Paribas en header
- ExpÃ©rience utilisateur optimisÃ©e

## ðŸš€ Compilation et ExÃ©cution

### PrÃ©requis

- .NET Framework 4.8 SDK
- MSBuild (fourni avec Visual Studio ou .NET Framework SDK)
- Windows 7 ou supÃ©rieur

### Commandes de compilation

Ouvrir PowerShell dans le rÃ©pertoire du projet :

```powershell
# Compilation en mode Release
& "C:\Program Files (x86)\Microsoft Visual Studio\2019\BuildTools\MSBuild\Current\Bin\MSBuild.exe" "BacklogManager.sln" /t:Rebuild /p:Configuration=Release /v:minimal

# Ou en mode Debug
& "C:\Program Files (x86)\Microsoft Visual Studio\2019\BuildTools\MSBuild\Current\Bin\MSBuild.exe" "BacklogManager.sln" /t:Rebuild /p:Configuration=Debug /v:minimal
```

### Lancement de l'application

```powershell
# Mode Release
.\bin\Release\BacklogManager.exe

# Mode Debug
.\bin\Debug\BacklogManager.exe
```

### Premier lancement

Au premier dÃ©marrage, l'application :
1. CrÃ©e automatiquement la base de donnÃ©es SQLite
2. Initialise les 4 rÃ´les par dÃ©faut
3. CrÃ©e 9 utilisateurs de test (voir `UTILISATEURS_TEST.txt`)
4. PrÃ©pare le dossier `Backups/` pour les sauvegardes

## ðŸ“‚ Structure du projet

```
BacklogManager/
â”œâ”€â”€ Domain/              # ModÃ¨les de domaine
â”‚   â”œâ”€â”€ BacklogItem.cs   # TÃ¢che
â”‚   â”œâ”€â”€ Projet.cs        # Projet
â”‚   â”œâ”€â”€ Utilisateur.cs   # Utilisateur
â”‚   â”œâ”€â”€ Role.cs          # RÃ´le et permissions
â”‚   â”œâ”€â”€ CRA.cs           # Compte-rendu d'activitÃ©
â”‚   â”œâ”€â”€ Sprint.cs        # Sprint
â”‚   â”œâ”€â”€ AuditLog.cs      # Log d'audit
â”‚   â”œâ”€â”€ Demande.cs       # Demande mÃ©tier
â”‚   â””â”€â”€ Enums.cs         # Ã‰numÃ©rations
â”œâ”€â”€ Services/            # Logique mÃ©tier et accÃ¨s donnÃ©es
â”‚   â”œâ”€â”€ IDatabase.cs     # Interface base de donnÃ©es
â”‚   â”œâ”€â”€ SqliteDatabase.cs    # ImplÃ©mentation SQLite
â”‚   â”œâ”€â”€ JsonDatabase.cs      # ImplÃ©mentation JSON (legacy)
â”‚   â”œâ”€â”€ BacklogService.cs    # Service principal
â”‚   â”œâ”€â”€ CRAService.cs        # Service CRA
â”‚   â”œâ”€â”€ AuthenticationService.cs  # Authentification
â”‚   â”œâ”€â”€ PermissionService.cs      # Gestion permissions
â”‚   â”œâ”€â”€ AuditLogService.cs        # TraÃ§abilitÃ©
â”‚   â”œâ”€â”€ NotificationService.cs    # Notifications
â”‚   â”œâ”€â”€ JoursFeriesService.cs     # Jours fÃ©riÃ©s franÃ§ais
â”‚   â””â”€â”€ InitializationService.cs  # Initialisation donnÃ©es
â”œâ”€â”€ ViewModels/          # MVVM ViewModels
â”‚   â”œâ”€â”€ MainViewModel.cs
â”‚   â”œâ”€â”€ BacklogViewModel.cs
â”‚   â”œâ”€â”€ KanbanViewModel.cs
â”‚   â”œâ”€â”€ CRAViewModel.cs
â”‚   â”œâ”€â”€ CRACalendrierViewModel.cs
â”‚   â”œâ”€â”€ CRAHistoriqueViewModel.cs
â”‚   â””â”€â”€ ArchivesViewModel.cs
â”œâ”€â”€ Views/               # Vues XAML
â”‚   â”œâ”€â”€ DashboardView.xaml      # Dashboard
â”‚   â”œâ”€â”€ BacklogView.xaml        # Backlog
â”‚   â”œâ”€â”€ KanbanView.xaml         # Kanban
â”‚   â”œâ”€â”€ CRAView.xaml            # CRA
â”‚   â”œâ”€â”€ TimelineView.xaml       # Planning
â”‚   â”œâ”€â”€ AdminView.xaml          # Administration
â”‚   â”œâ”€â”€ ParametresWindow.xaml   # ParamÃ¨tres systÃ¨me
â”‚   â””â”€â”€ GuideUtilisateurWindow.xaml  # Guide
â”œâ”€â”€ Converters/          # Convertisseurs WPF
â”œâ”€â”€ Shared/              # Utilitaires
â”‚   â”œâ”€â”€ RelayCommand.cs
â”‚   â””â”€â”€ BooleanToVisibilityConverter.cs
â”œâ”€â”€ Images/              # Ressources graphiques
â”œâ”€â”€ App.xaml
â”œâ”€â”€ MainWindow.xaml      # FenÃªtre principale
â””â”€â”€ README.md
```

## ðŸ“– Utilisation

### Connexion
1. Lancer l'application
2. Entrer un code utilisateur (ex: J04831 pour un dÃ©veloppeur, J00001 pour admin)
3. Cliquer sur "Se connecter"

### Dashboard
- Vue d'ensemble de votre activitÃ©
- Cliquez sur une activitÃ© rÃ©cente pour naviguer vers la tÃ¢che
- AccÃ©dez rapidement aux fonctionnalitÃ©s via les boutons d'actions

### Backlog
- CrÃ©ez des tÃ¢ches avec "âž• Nouvelle TÃ¢che" (si autorisÃ©)
- CrÃ©ez des congÃ©s/support avec "âž• CongÃ©s/Support" (tous les utilisateurs)
- Utilisez les filtres pour affiner la vue
- Double-cliquez sur une tÃ¢che pour l'Ã©diter

### Kanban
- Glissez-dÃ©posez les cartes entre les colonnes
- Filtrez par dÃ©veloppeur ou projet
- Les changements sont sauvegardÃ©s automatiquement

### CRA (Compte-Rendu d'ActivitÃ©)
- **Onglet Calendrier** : saisissez votre temps par jour
- **Onglet Historique** : consultez vos saisies passÃ©es
- Les jours fÃ©riÃ©s sont dÃ©tectÃ©s automatiquement
- 1 jour = 8 heures

### ParamÃ¨tres (Admin uniquement)
- Activez la sauvegarde automatique
- Configurez l'intervalle (minutes)
- Exportez vos donnÃ©es (SQLite, JSON, Complet)
- Importez une base de donnÃ©es de backup
