=====================================
    BacklogManager - Version Production
=====================================

INSTALLATION
------------
1. Double-cliquez sur InstallBacklogManager.vbs
2. Acceptez l'élévation des privilèges (UAC)
3. L'application sera installée dans: C:\SGI_SUPPORT\APPLICATIONS\BacklogManager
4. L'application se lancera automatiquement

OU

1. Clic droit sur Install.ps1 → "Exécuter avec PowerShell" (en tant qu'admin)
2. Suivre les instructions


CONFIGURATION
-------------
Le fichier config.ini permet de configurer l'application:

[Database]
DatabasePath=data\backlog.db

Chemins supportés:
- Chemin relatif: data\backlog.db (par défaut, dans le dossier de l'application)
- Chemin absolu: C:\Data\BacklogManager\backlog.db
- Réseau: \\serveur\partage\BacklogManager\backlog.db

[Update]
UpdateServerPath=

Pour activer les mises à jour automatiques, indiquez le chemin vers le serveur:
UpdateServerPath=\\serveur\partage\BacklogManager\Updates


PREMIÈRE UTILISATION
---------------------
- L'utilisateur connecté automatiquement sera créé en tant qu'Administrateur
- Email par défaut: username@bnpparibas.com
- Vous pouvez modifier vos informations dans: Administration → Gestion des utilisateurs


CARACTÉRISTIQUES
-----------------
✓ Connexion automatique avec authentification Windows
✓ Base de données SQLite configurable
✓ Mode multi-utilisateurs avec journalisation WAL
✓ Rôles et permissions (Administrateur, Chef de Projet, Business Analyst, Développeur)
✓ Gestion de backlog, sprints et tâches
✓ Planning Poker
✓ Gestion des CRA
✓ Tableau Kanban
✓ Archives et historique
✓ Système de mise à jour automatique


MISES À JOUR AUTOMATIQUES
--------------------------
L'application vérifie automatiquement les mises à jour au démarrage.

Pour activer cette fonctionnalité, configurez dans config.ini:

[Update]
UpdateServerPath=\\serveur\partage\BacklogManager\Updates

Voir GUIDE_MISE_A_JOUR.txt pour plus d'informations sur la configuration du serveur.


SUPPORT
-------
Pour toute question ou problème, contactez votre administrateur système.
