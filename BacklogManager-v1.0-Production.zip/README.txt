=====================================
    BacklogManager - Version Production
=====================================

INSTALLATION
------------
1. Copiez tout le contenu de ce dossier vers l'emplacement souhaité
   Exemple: C:\Program Files\BacklogManager\

2. Lancez BacklogManager.exe

3. L'application se connectera automatiquement avec votre compte Windows


CONFIGURATION
-------------
Le fichier config.ini permet de configurer l'application:

[Database]
DatabasePath=data\backlog.db

Chemins supportés:
- Chemin relatif: data\backlog.db (par défaut, dans le dossier de l'application)
- Chemin absolu: C:\Data\BacklogManager\backlog.db
- Réseau: \\serveur\partage\BacklogManager\backlog.db

[Update]
UpdateServerPath=

Pour activer les mises à jour automatiques, indiquez le chemin vers le serveur:
UpdateServerPath=\\serveur\partage\BacklogManager\Updates


PREMIÈRE UTILISATION
---------------------
- L'utilisateur connecté automatiquement sera créé en tant qu'Administrateur
- Vous pouvez modifier vos informations dans: Administration → Gestion des utilisateurs


CARACTÉRISTIQUES
-----------------
✓ Connexion automatique avec authentification Windows
✓ Base de données SQLite configurable
✓ Mode multi-utilisateurs avec journalisation WAL
✓ Rôles et permissions (Administrateur, Chef de Projet, Business Analyst, Développeur)
✓ Gestion de backlog, sprints et tâches
✓ Planning Poker
✓ Gestion des CRA
✓ Tableau Kanban
✓ Archives et historique
✓ Système de mise à jour automatique


MISES À JOUR AUTOMATIQUES
--------------------------
L'application peut vérifier automatiquement les mises à jour.

Pour activer cette fonctionnalité, configurez dans config.ini:

[Update]
UpdateServerPath=\\serveur\partage\BacklogManager\Updates

L'application vérifiera au démarrage si une nouvelle version est disponible.
Voir GUIDE_MISE_A_JOUR.txt pour plus d'informations sur la configuration du serveur.


SUPPORT
-------
Pour toute question ou problème, contactez votre administrateur système.
